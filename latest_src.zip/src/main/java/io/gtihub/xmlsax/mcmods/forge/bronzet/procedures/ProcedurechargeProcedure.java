package io.gtihub.xmlsax.mcmods.forge.bronzet.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;

import io.gtihub.xmlsax.mcmods.forge.bronzet.init.BronzetModItems;
import io.gtihub.xmlsax.mcmods.forge.bronzet.init.BronzetModBlocks;

public class ProcedurechargeProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == BronzetModBlocks.COMPRESSEDREDSTONE
				.get().asItem()
				&& (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == BronzetModItems.BATTERY.get()) {
			if (entity instanceof LivingEntity _entity) {
				ItemStack _setstack = new ItemStack(BronzetModItems.POWEREDBATTERY.get());
				_setstack.setCount(1);
				_entity.setItemInHand(InteractionHand.OFF_HAND, _setstack);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
			if (entity instanceof Player _player) {
				ItemStack _stktoremove = new ItemStack(BronzetModBlocks.COMPRESSEDREDSTONE.get());
				_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1,
						_player.inventoryMenu.getCraftSlots());
			}
			if (entity instanceof Player _player)
				_player.giveExperiencePoints(5);
		}
	}
}
