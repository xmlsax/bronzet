
package io.gtihub.xmlsax.mcmods.forge.bronzet.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;

import io.gtihub.xmlsax.mcmods.forge.bronzet.procedures.KillProcedure;
import io.gtihub.xmlsax.mcmods.forge.bronzet.init.BronzetModTabs;

public class XItem extends Item {
	public XItem() {
		super(new Item.Properties().tab(BronzetModTabs.TAB_BRONZETAB).stacksTo(1).rarity(Rarity.UNCOMMON));
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		KillProcedure.execute(entity, sourceentity);
		return retval;
	}
}
