
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package io.github.xmlsax.mcmods.forge.bronzet.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import io.github.xmlsax.mcmods.forge.bronzet.item.XItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.TintoolsSwordItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.TintoolsShovelItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.TintoolsPickaxeItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.TintoolsHoeItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.TintoolsAxeItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.TinnuggetItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.TiningotItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.RawtinItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.RawcarbongemItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.PoweredbatteryItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.NickelIngotItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.NickelArmorItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.NetheredstoniteIngotItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.MeltedinvarItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.MeltedconstantanItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.MeltedbronzeItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.MeltedNetheredstoniteItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.EndstoneDustItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.CarbongemItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.BronzeingotItem;
import io.github.xmlsax.mcmods.forge.bronzet.item.BatteryItem;
import io.github.xmlsax.mcmods.forge.bronzet.BronzetMod;

public class BronzetModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, BronzetMod.MODID);
	public static final RegistryObject<Item> TIN_ORE = block(BronzetModBlocks.TIN_ORE, BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> RAWTIN = REGISTRY.register("rawtin", () -> new RawtinItem());
	public static final RegistryObject<Item> TINBLOCK = block(BronzetModBlocks.TINBLOCK, BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> TININGOT = REGISTRY.register("tiningot", () -> new TiningotItem());
	public static final RegistryObject<Item> TINNUGGET = REGISTRY.register("tinnugget", () -> new TinnuggetItem());
	public static final RegistryObject<Item> TIN_PICKAXE = REGISTRY.register("tin_pickaxe", () -> new TintoolsPickaxeItem());
	public static final RegistryObject<Item> TIN_AXE = REGISTRY.register("tin_axe", () -> new TintoolsAxeItem());
	public static final RegistryObject<Item> TIN_SWORD = REGISTRY.register("tin_sword", () -> new TintoolsSwordItem());
	public static final RegistryObject<Item> TIN_SHOVEL = REGISTRY.register("tin_shovel", () -> new TintoolsShovelItem());
	public static final RegistryObject<Item> TIN_HOE = REGISTRY.register("tin_hoe", () -> new TintoolsHoeItem());
	public static final RegistryObject<Item> MELTEDBRONZE_BUCKET = REGISTRY.register("meltedbronze_bucket", () -> new MeltedbronzeItem());
	public static final RegistryObject<Item> BRONZEBLOCK = block(BronzetModBlocks.BRONZEBLOCK, BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> BRONZEINGOT = REGISTRY.register("bronzeingot", () -> new BronzeingotItem());
	public static final RegistryObject<Item> ALLOYER = block(BronzetModBlocks.ALLOYER, BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> RAWCARBONGEM = REGISTRY.register("rawcarbongem", () -> new RawcarbongemItem());
	public static final RegistryObject<Item> CARBONGEM = REGISTRY.register("carbongem", () -> new CarbongemItem());
	public static final RegistryObject<Item> NICKEL_ORE = block(BronzetModBlocks.NICKEL_ORE, BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> NICKEL_BLOCK = block(BronzetModBlocks.NICKEL_BLOCK, BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> NICKEL_INGOT = REGISTRY.register("nickel_ingot", () -> new NickelIngotItem());
	public static final RegistryObject<Item> NICKEL_ARMOR_HELMET = REGISTRY.register("nickel_armor_helmet", () -> new NickelArmorItem.Helmet());
	public static final RegistryObject<Item> NICKEL_ARMOR_CHESTPLATE = REGISTRY.register("nickel_armor_chestplate",
			() -> new NickelArmorItem.Chestplate());
	public static final RegistryObject<Item> NICKEL_ARMOR_LEGGINGS = REGISTRY.register("nickel_armor_leggings", () -> new NickelArmorItem.Leggings());
	public static final RegistryObject<Item> NICKEL_ARMOR_BOOTS = REGISTRY.register("nickel_armor_boots", () -> new NickelArmorItem.Boots());
	public static final RegistryObject<Item> MELTEDINVAR_BUCKET = REGISTRY.register("meltedinvar_bucket", () -> new MeltedinvarItem());
	public static final RegistryObject<Item> INVARBLOCK = block(BronzetModBlocks.INVARBLOCK, BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> CONSTANTANBLOCK = block(BronzetModBlocks.CONSTANTANBLOCK, BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> MELTEDCONSTANTAN_BUCKET = REGISTRY.register("meltedconstantan_bucket", () -> new MeltedconstantanItem());
	public static final RegistryObject<Item> CHARGER = block(BronzetModBlocks.CHARGER, BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> COMPRESSEDREDSTONE = block(BronzetModBlocks.COMPRESSEDREDSTONE, BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> BATTERY = REGISTRY.register("battery", () -> new BatteryItem());
	public static final RegistryObject<Item> POWEREDBATTERY = REGISTRY.register("poweredbattery", () -> new PoweredbatteryItem());
	public static final RegistryObject<Item> X = REGISTRY.register("x", () -> new XItem());
	public static final RegistryObject<Item> COMPRESS_NETHERITE = block(BronzetModBlocks.COMPRESS_NETHERITE, BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> DOUBLE_COMPRESSED_REDSTONE = block(BronzetModBlocks.DOUBLE_COMPRESSED_REDSTONE,
			BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> MELTED_NETHEREDSTONITE_BUCKET = REGISTRY.register("melted_netheredstonite_bucket",
			() -> new MeltedNetheredstoniteItem());
	public static final RegistryObject<Item> NETHEREDSTONITE_BLOCK = block(BronzetModBlocks.NETHEREDSTONITE_BLOCK, BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> NETHEREDSTONITE_INGOT = REGISTRY.register("netheredstonite_ingot", () -> new NetheredstoniteIngotItem());
	public static final RegistryObject<Item> DEGG_GENERATOR = block(BronzetModBlocks.DEGG_GENERATOR, BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> POWERED_NETHEREDSTONITE_BLOCK = block(BronzetModBlocks.POWERED_NETHEREDSTONITE_BLOCK,
			BronzetModTabs.TAB_BRONZETAB);
	public static final RegistryObject<Item> ENDSTONE_DUST = REGISTRY.register("endstone_dust", () -> new EndstoneDustItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
