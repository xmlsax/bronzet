
package io.github.xmlsax.mcmods.forge.bronzet.block;

import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.core.BlockPos;

import io.github.xmlsax.mcmods.forge.bronzet.init.BronzetModFluids;

public class MeltedNetheredstoniteBlock extends LiquidBlock {
	public MeltedNetheredstoniteBlock() {
		super(() -> (FlowingFluid) BronzetModFluids.MELTED_NETHEREDSTONITE.get(), BlockBehaviour.Properties.of(Material.LAVA).strength(100f)

		);
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}
}
