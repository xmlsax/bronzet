package io.github.xmlsax.mcmods.forge.bronzet.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.core.BlockPos;

import io.github.xmlsax.mcmods.forge.bronzet.init.BronzetModItems;
import io.github.xmlsax.mcmods.forge.bronzet.init.BronzetModBlocks;

public class PowerNetheredstoniteProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == BronzetModItems.POWEREDBATTERY
				.get()) {
			if (entity instanceof LivingEntity _entity) {
				ItemStack _setstack = new ItemStack(BronzetModItems.BATTERY.get());
				_setstack.setCount(1);
				_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
			world.setBlock(new BlockPos(x, y, z), BronzetModBlocks.POWERED_NETHEREDSTONITE_BLOCK.get().defaultBlockState(), 3);
		}
	}
}
